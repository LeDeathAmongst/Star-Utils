# Star_Utils - Shared tools
### Made Initially by AAA3A for [AAA3A-cogs](https://github.com/AAA3A-AAA3A/AAA3A-cogs), modified by Star for [Star-Cogs](https://github.com/LeDeathAmongst/Star-Cogs)

The "Star_Utils" sub-folder is a PIP package, automatically downloaded by all my cogs.

For more info (docs, contributing, contact), please check the Star-Cogs repository.

Thanks to Vexed for the code and the documentation to use Telemetry with Sentry (https://github.com/Vexed01/vex-cog-utils/blob/ba8adb3d270c968bc7ff3e3b977ac90ff752dca3/vexcogutils/sentry.py)!

## Install

Type the following command in your console:

```
python -m pip install git+https://github.com/LeDeathAmongst/AAA3A_utils.git
```
